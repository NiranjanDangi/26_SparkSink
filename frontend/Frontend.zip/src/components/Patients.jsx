import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { MapContainer, Marker, TileLayer, Polyline } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import toast, { Toaster } from "react-hot-toast";

const nurseIcon = new L.Icon({
  iconUrl: "https://cdn-icons-png.flaticon.com/512/1534/1534103.png",
  iconSize: [32, 32],
});

const shivajinagarCoords = [18.5196, 73.8551]; // Patient's location
const nursesCoords = [
  [18.4802, 73.879], // Nurse 1
  [18.55, 73.9], // Nurse 2
  [18.53, 73.86], // Nurse 3
  [18.5, 73.87], // Nurse 4 (Nearby)
];

const Patients = () => {
  const { id } = useParams();
  const [emergencyType, setEmergencyType] = useState("");
  const [location, setLocation] = useState(shivajinagarCoords);
  const [nearestNurse, setNearestNurse] = useState(null);
  const [distance, setDistance] = useState(null);
  const [eta, setEta] = useState(null);
  const [isNurseAvailable, setIsNurseAvailable] = useState(false);
  const [transportMode, setTransportMode] = useState("Walking");
  const [patientData, setPatientData] = useState(null);

  const haversineDistance = (coords1, coords2) => {
    const R = 6371; // Radius of the Earth in km
    const latDiff = (coords2[0] - coords1[0]) * (Math.PI / 180);
    const lonDiff = (coords2[1] - coords1[1]) * (Math.PI / 180);

    const a =
      Math.sin(latDiff / 2) * Math.sin(latDiff / 2) +
      Math.cos(coords1[0] * (Math.PI / 180)) *
        Math.cos(coords2[0] * (Math.PI / 180)) *
        Math.sin(lonDiff / 2) *
        Math.sin(lonDiff / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c; // Distance in km
  };

  const fetchPatientData = async () => {
    if (id) {
      try {
        const response = await fetch(`http://127.0.0.1:3001/patient/${id}`, {
          method: "GET",
          credentials: "include", // Send cookies with request
        });

        if (!response.ok) {
          throw new Error("Failed to fetch patient data");
        }

        const data = await response.json();
        setPatientData(data);
        console.log("Patient data fetched:", data);
      } catch (error) {
        console.error("Error fetching patient data:", error.message);
      }
    }
  };

  useEffect(() => {
    fetchPatientData();
  }, [id]);

  const findNearestNurse = () => {
    let closestDistance = Infinity;
    let closestNurse = null;

    nursesCoords.forEach((nurseCoords) => {
      const distanceToNurse = haversineDistance(location, nurseCoords);
      if (distanceToNurse < closestDistance) {
        closestDistance = distanceToNurse;
        closestNurse = nurseCoords;
      }
    });

    setNearestNurse(closestNurse);
    setDistance(closestDistance.toFixed(2));
    calculateETA(closestDistance);
    setIsNurseAvailable(true);
  };

  const calculateETA = (distance) => {
    const speed =
      transportMode === "Walking" ? 5 : transportMode === "Cycling" ? 15 : 30;
    const estimatedTime = (distance / speed) * 60; // ETA in minutes
    setEta(estimatedTime.toFixed(0));
  };

  const handleEmergencyClick = (type) => {
    setEmergencyType(type);
    toast.success(
      `${
        type.charAt(0).toUpperCase() + type.slice(1)
      } emergency! Nurses have been notified.`
    );

    setTimeout(() => {
      toast.loading("Finding the nearest nurse...", { duration: 3000 });
    }, 0);

    findNearestNurse();
  };

  return (
    <div className="flex flex-col md:flex-row h-screen">
      <div className="w-full md:w-1/4 p-4 bg-gray-100">
        <h2 className="text-2xl font-semibold mb-4">Patient Profile</h2>
        {patientData ? (
          <>
            <p>
              <strong>Name:</strong> {patientData.name}
            </p>
            <p>
              <strong>Current Location:</strong> Shivajinagar, Pune
            </p>
            <p>
              <strong>Registered Address:</strong> {patientData.address}
            </p>
            <p>
              <strong>Medical History:</strong>{" "}
              {patientData.medicalHistory?.join(", ") || "No history"}
            </p>
          </>
        ) : (
          <p>Loading patient data...</p>
        )}
      </div>

      <div className="w-full md:w-1/2 p-4">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-2">Emergency Actions</h2>
          <button
            onClick={() => handleEmergencyClick("mild")}
            className="bg-yellow-400 text-white py-2 px-4 mr-2 rounded"
          >
            Mild Emergency
          </button>
          <button
            onClick={() => handleEmergencyClick("moderate")}
            className="bg-orange-400 text-white py-2 px-4 mr-2 rounded"
          >
            Moderate Emergency
          </button>
          <button
            onClick={() => handleEmergencyClick("severe")}
            className="bg-red-500 text-white py-2 px-4 rounded"
          >
            Severe Emergency
          </button>
        </div>

        <div>
          <label className="block mb-2">Select Transport Mode:</label>
          <select
            value={transportMode}
            onChange={(e) => setTransportMode(e.target.value)}
            className="border p-2 rounded"
          >
            <option>Walking</option>
            <option>Cycling</option>
            <option>Driving</option>
          </select>
        </div>

        <h3 className="text-xl font-semibold mt-6">
          Nearest Nurse Information:
        </h3>
        {isNurseAvailable ? (
          <div>
            <p>
              <strong>Distance:</strong> {distance} km
            </p>
            <p>
              <strong>ETA:</strong> {eta} minutes
            </p>
          </div>
        ) : (
          <p>No nurse found yet.</p>
        )}
      </div>

      <div className="w-full md:w-1/2">
        <MapContainer center={location} zoom={13} style={{ height: "100%" }}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <Marker position={location} />
          {nearestNurse && (
            <>
              <Marker position={nearestNurse} icon={nurseIcon} />
              <Polyline positions={[location, nearestNurse]} color="blue" />
            </>
          )}
        </MapContainer>
      </div>

      <Toaster position="top-right" />
    </div>
  );
};

export default Patients;